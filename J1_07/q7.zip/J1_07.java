import java.util.Scanner;

public class J1_07{
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);


        Triangulo tri = new Triangulo();


        tri.a.x = scan.nextDouble();
        tri.a.y = scan.nextDouble();

        tri.b.x = scan.nextDouble();
        tri.b.y = scan.nextDouble();

        tri.c.x = scan.nextDouble();
        tri.c.y = scan.nextDouble();

        double perimetroTri = tri.perimetro();


        System.out.printf("%.5f\n",perimetroTri);

        scan.close();
        
    }
}